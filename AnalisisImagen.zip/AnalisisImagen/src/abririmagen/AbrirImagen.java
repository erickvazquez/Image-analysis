
package abririmagen;


public class AbrirImagen {

    public static void main(String[] args) {
        Muestra ventana=new Muestra();
        ventana.setVisible(true);
    }
    
}
